package com.webapp.model;

import java.io.Serial;
import java.io.Serializable;

public abstract class Section implements Serializable {
    @Serial
    private static final long serialVersionUID = 8400884336911400060L;
}
