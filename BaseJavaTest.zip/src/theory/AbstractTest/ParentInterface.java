package theory.AbstractTest;

public interface ParentInterface {
    void parentMethod();
}
