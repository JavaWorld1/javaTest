package theory.AbstractTest;

public abstract class AbstractClass implements ChildInterface{

}

