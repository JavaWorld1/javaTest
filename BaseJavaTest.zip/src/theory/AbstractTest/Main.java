package theory.AbstractTest;

public class Main {
    public static void main(String[] args) {
        ParentInterface interfaceTest = new ConcreteClass();
        interfaceTest.parentMethod();
    }
}
