package theory.AbstractTest;

public class ConcreteClass extends AbstractClass {

    @Override
    public void childMethod() {

    }

    @Override
    public void parentMethod() {

    }
}
