package theory.AbstractTest;

public interface ChildInterface extends ParentInterface {
    void childMethod();
}
