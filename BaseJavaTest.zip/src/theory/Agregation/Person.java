package theory.Agregation;

public class Person {
    private String name;
    private Address address;

    // Метод, связывающий объект адреса с человеком
    public void setAddress(Address address) {
        this.address = address;
    }
}

