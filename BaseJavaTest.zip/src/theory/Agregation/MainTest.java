package theory.Agregation;

public class MainTest {
    public static void main(String[] args) {
        Person Max = new Person();
        Person John = new Person();
        Max.setAddress(new Address("Molodezhka"));
        John.setAddress(new Address("5 MK"));
    }
}
