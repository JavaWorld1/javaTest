package theory.Agregation;

public class Address {
    private String street;

    public Address(String street) {
        this.street = street;
    }
}
