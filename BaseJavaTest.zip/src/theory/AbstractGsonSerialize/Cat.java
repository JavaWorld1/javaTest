package theory.AbstractGsonSerialize;

class Cat extends Animal {
    int lives;

    public Cat(String name, int lives) {
        super(name);
        this.lives = lives;
    }
}