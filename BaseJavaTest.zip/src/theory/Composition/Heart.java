package theory.Composition;

public class Heart {
    public void beat() {
        System.out.println("Heart is beating...");
    }
}
