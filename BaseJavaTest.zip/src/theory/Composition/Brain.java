package theory.Composition;

public class Brain {
    public void think() {
        System.out.println("Brain is thinking...");
    }
}
